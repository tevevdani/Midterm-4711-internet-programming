let questions = [
    {
    numb: 1,
    question: "Inside which HTML element do we put the JavaScript ",
    answer: "<script>",
    options: [
      "&lt;scripting>",
      "&lt;js>",
      "&lt;javascript>",
      "&lt;script>"
    ]
  },
    {
    numb: 2,
    question: "iii. The external JavaScript file must contain the <script> tag ",
    answer: "False",
    options: [
      "True",
      "False",
      "None",
      "Both"
    ]
  },
    {
    numb: 3,
    question: "How do you write \"Hello World\" in an alert box?",
    answer: "Alert(“Hello World”)",
    options: [
      "Alert(“Hello World”)",
      "alertBox(“Hello World”);",
      "msg(“Hello World”);",
      "msgBoxl(“Hello World”);"
    ]
  },
];